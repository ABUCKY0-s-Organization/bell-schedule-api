## announcements Table

TITLE (text) | DESCRIPTION (text) | TAGS (json) | ID (int4) {autoIncremented} | DATE (timestamp)

## schedules Table

####
